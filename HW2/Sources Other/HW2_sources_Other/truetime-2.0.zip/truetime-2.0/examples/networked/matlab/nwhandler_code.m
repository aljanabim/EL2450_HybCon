function [exectime, data] = nwhandler_code(seg, data)

ttCreateJob(data)
exectime = -1;
