function [exectime, data] = redMsgRcvMaster(seg, data)

global xBall yBall xPos yPos takePass 

msg = ttGetMsg;
node = msg.node;
takePass(node)=0;

if (msg.coll~=1)
  ballZone = getBallZone(xBall,yBall);
  
  
  %R�knar ut vilken nod som �r n�rmast bollen och hur l�ng det �r till m�let
  
  [node, dist] = closestNode;
  returnPos(node);
  
  %Noden �r under bollen. Passa, skjuta eller dribbla?
  if(yPos(node)<yBall)
    %Passa
    %Funktionen returnerar n�rmaste nod ovanf�r bollen. Returnerar -1 om det
    %inte finns n�gon nod ovanf�r
    
    [toPass, distToPass] = whichNodeToPass(node,1);
    %Om det finns n�gon ovanf�r att passa.
    if(toPass~=-1)
      %Passa bollen till toPass. Allts� skicka nodens nya referenspunkt och medela
      %toPass att bollen �r p� v�g.
      pass(node, toPass);
      exectime = -1;
      return
      
      
      %Om det inte finns n�gon ovanf�r att passa.
    else
      %Dribbla runt bollen och passa eller skjut.
      dribble(node);
      exectime = -1;
      return
      
    end
    
    %Nu �r noden ovanf�r bollen och ska antingen passa, dribbla eller skjuta.
  else
    ballReach = 13;
    %Om noden �r f�r l�ngt ifr�n m�let ska den passa n�gon som n�r m�let.
    if(sqrt((xBall)^2 + (yBall+27)^2)>ballReach)
      [toPass, distToPass] = whichNodeToPass(node,2);
      if( (toPass==-1) | (distToPass > ballReach))
	dribble(node);
	exectime = -1;
	return
      else
	pass(node, toPass);
	exectime = -1;
	return
      end
      
    else
      goal(node);
      exectime = -1;
      return 
      
    end
  end
  
  
else
  % Collision
  ref = getRandRef(node);
  newRef.xRef = ref(1);
  newRef.yRef = ref(2);
  ttSendMsg(node, newRef, 10); 
  %D� en nod har krockat kommer den att vara satt ur spel ett litet tag.
  %D�rf�r skickas n�stn�rmaste nod till bollens position.
  
  [nearestNode, distToNearestNode] = whichNodeToPass(node, 3);
  
  newRef = kickBall(0,-27,nearestNode,3);
  ttSendMsg(nearestNode, newRef, 10);
end				

exectime = -1;


function returnPos(node)
global yBall xPos yPos takePass state
%if (data.nodeID == 1) % red team's master
if (yBall>=10)
  newRef.xRef=1000;
elseif (yBall<-10)
  newRef.xRef=3000;
else
  newRef.xRef=2000;
end
for i=2:5
  %Skickar tillbaka noderna till deras ursprungspositioner
  if(i~=node & takePass(i)==0)
    ttSendMsg(i, newRef, 10);
    state{i}='Idle';
  end
end



function [newRef, newBall] = kickBall(xRef,yRef, node, func)
%func = 1 skjut mot m�l
%func = 2 Passa med spelare
%func = 3 Dribbla

global xBall yBall xPos yPos redForce
if func==1
  redForce=1;
  distance=2;
end

if func==2
  %Skjuter upp eller ner?
  distBallPass = sqrt((xRef-xBall)^2+(yRef-yBall)^2);
  
  if(yBall>yRef)
    v=asin(abs(xBall-xRef)/distBallPass);
    %ballForce = sqrt((xRef-xBall)^2+(yRef-yBall)^2)/15;
  else
    v=pi/2+acos(abs(xBall-xRef)/distBallPass);
    %ballForce = sqrt((xRef-xBall)^2+(yRef-yBall)^2)/20;
  end
  ballForce=distBallPass/(15+4*sin(v/2));
  
  if ballForce>=1
    redForce = 1;
  else
    redForce = ballForce;
  end  
  distance=2;
  if redForce < 0.3
    redForce = 0.3;
  end
  
end

if func==3
  redForce=0.2;
  distance=1.7;
end


ballSize=1;
xAimVec = xRef - xBall;
yAimVec = yRef - yBall;
lengthAimVec = sqrt(xAimVec^2 + yAimVec^2);

%Vi f�rs�ker f�rutsp� var bollen kommer att hamna.
newBall.xRef =  xBall + redForce *2*8*xAimVec/(lengthAimVec);
newBall.yRef =  yBall + redForce *2*8*yAimVec/(lengthAimVec) +2;


if(sqrt((xBall-xPos(node))^2 + (yBall-yPos(node))^2)>=distance)
  
  %S�tter referenspunken bakom bollen, i f�rh�llande till m�let
  newRef.xRef = xBall - (ballSize*xAimVec)/lengthAimVec;
  newRef.yRef = yBall - (ballSize*yAimVec)/lengthAimVec;
  
else
  newRef.xRef = xBall;
  newRef.yRef = yBall;
end

if func==3 & newRef.yRef > 0 & yPos(node)< yBall
  if (xPos(node) > newRef.xRef - 2) | (xPos(node) < newRef.xRef + 2)
    if xPos(node) > 0
      newRef.xRef = newRef.xRef - 1;
    else
      newRef.xRef = newRef.xRef + 1;
    end
  end
end





function [node, dist] = closestNode
global xBall yBall xPos yPos 
dist = 1000;
for i = 2:5
  distToBall = sqrt((xBall-xPos(i))^2 + (yBall-yPos(i))^2);
  distFromMoteToGoal(i-1) = sqrt((xPos(i))^2 + (yPos(i)+27)^2);
  if(dist>distToBall)
    dist=distToBall;
    node = i;
  end   
end




function [toPass, distToPass] = whichNodeToPass(node, func)
%func=1 Noden ligger under bollen.
%func=2 Noden ligger �ver bollen.
%func=3 N�rmasta noden
global xBall yBall xPos yPos 
distToPass=50;
toPass=-1;
for i = 2:5
  %Ber�knar till vem noden ska passa. 	
  if(func==1)
    if(yBall<=yPos(i))
      toPassY = sqrt((xPos(i)-xBall)^2+(yPos(i)-yBall)^2);
      if(toPassY<distToPass & i ~= node)
	distToPass=toPassY;
	toPass=i;
      end
    end	 
  end	  
  if(func==2)
    if(yBall>=yPos(i))
      toPassY = sqrt((xPos(i)-xBall)^2+(yPos(i)-yBall)^2);
      if(toPassY<distToPass & i ~= node)
	distToPass=toPassY;
	toPass=i;
      end
    end
  end
  if(func==3)
    toPassY = sqrt((xPos(i)-xBall)^2+(yPos(i)-yBall)^2);
    if(toPassY<distToPass & i ~= node)
      distToPass=toPassY;
      toPass=i;
    end
  end	 	  
end		



function pass(node, toPass)
global xPos yPos takePass state
%sprintf('LINE 39: Mote: %d, Passa till mote: %d',node,toPass)
state{node}=['Pass to ' num2str(toPass)];
state{toPass}=['Receive pass from ' num2str(node)];
[newRef, newBall] = kickBall(xPos(toPass),yPos(toPass)-3,node,2);
takePass(toPass) = 1;
if xPos(toPass)<0
  newBall.xRef = newBall.xRef - 2;
else
  newBall.xRef = newBall.xRef + 2;
end
ttSendMsg(node,newRef,10);
ttSendMsg(toPass,newBall,10);




function dribble(node)
global xBall yBall xPos yPos state
state{node}='Dribble';	
%sprintf('LINE 39: Mote: %d, Dribbla',node)
[newRef, newBall] = kickBall(0,-27,node,3);
ttSendMsg(node, newRef,10);


function goal(node)
global state
%sprintf('Mote: %d, SKJUT',node)
state{node}='Shoot';
temp = rand(1);
slump = rand(1);
if temp < 0.5
  slump = -slump;
end

[newRef, newBall] = kickBall(slump,-27,node,1);
ttSendMsg(node, newRef, 10);